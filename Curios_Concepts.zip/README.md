# Template for datapack Made by L.Lawliet

---

`.gitkeep` file doesn't have any meaning its just there to keep the empty folders there in git. Feel free to remove it.

